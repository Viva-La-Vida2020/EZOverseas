from google.cloud import dialogflow
from google.protobuf.json_format import MessageToDict
import os
import re
from google.cloud import dialogflow
from extract_data import display_language_requirement,display_project_information

"Replace auth_path with your own path"

auth_path = r"C:\Users\Administrator\AppData\Roaming\gcloud\application_default_credentials.json"
os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = auth_path

def detect_intent_texts(project_id, session_id, texts, language_code):
    """Returns the result of detect intent with texts as inputs.

    Using the same `session_id` between requests allows continuation
    of the conversation."""
    # from google.cloud import dialogflow

    session_client = dialogflow.SessionsClient()

    session = session_client.session_path(project_id, session_id)
    print("Session path: {}\n".format(session))

    for text in texts:
        text_input = dialogflow.TextInput(text=text, language_code=language_code)

        query_input = dialogflow.QueryInput(text=text_input)

        response = session_client.detect_intent(
            request={"session": session, "query_input": query_input}
        )

        print("=" * 20)
        print("Query text: {}".format(response.query_result.query_text))
        print(
            "Detected intent: {} (confidence: {})\n".format(
                response.query_result.intent.display_name,
                response.query_result.intent_detection_confidence,
            )
        )
        print("Fulfillment text: {}\n".format(response.query_result.fulfillment_text))


def detect_intent_texts_with_location(
    project_id, location_id, session_id, texts, language_code
):
    """Returns the result of detect intent with texts as inputs.

    Using the same `session_id` between requests allows continuation
    of the conversation."""

    session_client = dialogflow.SessionsClient(
        client_options={"api_endpoint": f"{location_id}-dialogflow.googleapis.com"}
    )

    session = (
        f"projects/{project_id}/locations/{location_id}/agent/sessions/{session_id}"
    )
    print(f"Session path: {session}\n")

    for text in texts:
        text_input = dialogflow.TextInput(text=text, language_code=language_code)

        query_input = dialogflow.QueryInput(text=text_input)

        response = session_client.detect_intent(
            request={"session": session, "query_input": query_input}
        )
        intent = response.query_result.intent.display_name
        if intent == 'programs_language_requirement':
            response_program = response.query_result.parameters.pb['programs']
            pro_name = MessageToDict(response_program)
            #正则表达式匹配需要完善
            pro_name = re.sub(r'^[ /\\"]+|[ /\\"]+$', '',pro_name)
            print(pro_name)
            response_univ = response.query_result.parameters.pb['university']
            univ_name = MessageToDict(response_univ)
            univ_name = re.sub(r'^[ /\\"]+|[ /\\"]+$', '',univ_name)
            print(univ_name)


            #display_language_requirement("Australian Catholic University", "Master of Public Health")
            info = display_language_requirement(univ_name, pro_name)
        elif intent == 'project_description':
            print(intent)
            response_program = response.query_result.parameters.pb['programs']
            pro_name = MessageToDict(response_program)
            # 正则表达式匹配需要完善
            pro_name = re.sub(r'^[ /\\"]+|[ /\\"]+$', '', pro_name)
            print(pro_name)
            response_univ = response.query_result.parameters.pb['university']
            univ_name = MessageToDict(response_univ)
            univ_name = re.sub(r'^[ /\\"]+|[ /\\"]+$', '', univ_name)
            print(univ_name)

            # display_language_requirement("Australian Catholic University", "Master of Public Health")
            info = display_project_information(univ_name, pro_name)
        #print(response.query_result.parameters.pb['university']['string_value'])

        # print("=" * 20)
        # print(f"Query text: {response.query_result.query_text}")
        # print(
        #     f"Detected intent: {response.query_result.intent.display_name} (confidence: {response.query_result.intent_detection_confidence,})\n"
        # )
        # print(f"Fulfillment text: {response.query_result.fulfillment_text}\n")
        #if response.query_result.intent.display_name=='programs_language_requirement':
        return info






if __name__ == '__main__':
    info = detect_intent_texts_with_location('studyabroad-wocb', 'global', 'a0be3e56-9fcf-153a-d408-c380b8fb58c8', ['what is the project introduction about Master of Humanitarian Assistance at the Deakin University'], 'en')
    print('info:', info)