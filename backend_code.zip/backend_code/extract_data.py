import mysql.connector
def display_language_requirement(university,program):
    #print(university,program)
    db_connection = mysql.connector.connect(
        host="localhost",  # MySQL服务器地址
        user="root",   # MySQL用户名
        password="root",  # MySQL密码
        database="mysql"  # 数据库名称
    )
    cursor = db_connection.cursor()
    #template1 = ['Australian Catholic University','Master of Public Health']
    template1 = [university,program]

    # 执行SQL查询
    query = "SELECT entry_criteria FROM programs_and_major where univ_name=%s and program_name=%s "
    cursor.execute(query,template1)

    # print('项目简介................')
    # 获取查询结果
    results = cursor.fetchall()
    info = ''
    for r in results:
        info = info.join(str(r[0]))
    # for row in results:
    #     print(row)
    return info
#display_language_requirement('Australian Catholic University','Master of Public Health')
def display_project_information(university,program):
    #print(university,program)
    db_connection = mysql.connector.connect(
        host="localhost",  # MySQL服务器地址
        user="root",   # MySQL用户名
        password="root",  # MySQL密码
        database="mysql"  # 数据库名称
    )
    cursor = db_connection.cursor()
    #template1 = ['Australian Catholic University','Master of Public Health']
    template1 = [university,program]

    # 执行SQL查询
    query = "SELECT programs_summary FROM programs_and_major where univ_name=%s and program_name=%s "
    cursor.execute(query,template1)

    # print('项目简介................')
    # 获取查询结果
    results = cursor.fetchall()
    info = ''
    for r in results:
        info = info.join(str(r[0]))
    # for row in results:
    #     print(row)
    return info